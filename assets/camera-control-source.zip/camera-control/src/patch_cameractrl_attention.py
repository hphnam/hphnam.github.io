import os
import sys

FILEPATH = "cameractrl/models/attention_processor.py"

if not os.path.isfile(FILEPATH):
    print(f"Not found: {FILEPATH}")
    print("Run this script from the CameraCtrl repo root.")
    sys.exit(1)

with open(FILEPATH, "r") as f:
    content = f.read()

if "import torch.nn.functional as F" not in content:
    content = content.replace(
        "import torch", "import torch\nimport torch.nn.functional as F", 1)

# Replace the attention matrix computation with SDPA
OLD = """        attention_probs = attn.get_attention_scores(query, key, attention_mask)
        hidden_states = torch.bmm(attention_probs, value)"""

NEW = """        # patched for 12GB GPU
        hidden_states = F.scaled_dot_product_attention(
            query.unsqueeze(0) if query.dim() == 3 else query,
            key.unsqueeze(0) if key.dim() == 3 else key,
            value.unsqueeze(0) if value.dim() == 3 else value,
            attn_mask=attention_mask,
        )
        if hidden_states.dim() == 4:
            hidden_states = hidden_states.squeeze(0)"""

if OLD in content:
    content = content.replace(OLD, NEW)
    with open(FILEPATH, "w") as f:
        f.write(content)
    print(f"Patched: {FILEPATH}")
    print("Replaced")
elif "scaled_dot_product_attention" in content:
    print("Already patched")
else:
    print("fail")
    sys.exit(1)
