import os
import sys
import subprocess

H_DRIVE = "/home/hoangp/h-drive"
WORK_DIR = f"{H_DRIVE}/CW"
VENV_DIR = f"{H_DRIVE}/envs/scc456"
CAMERACTRL_DIR = f"{WORK_DIR}/CameraCtrl"
HF_CACHE = f"{H_DRIVE}/.cache/huggingface"

pip = f"{VENV_DIR}/bin/pip"
python = f"{VENV_DIR}/bin/python3"


def run(cmd, **kwargs):
    subprocess.run(cmd, shell=True, check=True, **kwargs)


if not os.environ.get("VIRTUAL_ENV"):
    os.environ["VIRTUAL_ENV"] = VENV_DIR
    os.environ["PATH"] = f"{VENV_DIR}/bin:" + os.environ["PATH"]

os.environ["HF_HOME"] = HF_CACHE
os.environ["TRANSFORMERS_CACHE"] = f"{HF_CACHE}/hub"
os.makedirs(HF_CACHE, exist_ok=True)

# GPU check
run(f"""{python} -c "
import torch
if torch.cuda.is_available():
    print(f'GPU: {{torch.cuda.get_device_name(0)}}')
    print(f'VRAM: {{torch.cuda.get_device_properties(0).total_memory/1e9:.1f}} GB')
" """)

# Clone repo
if not os.path.isdir(CAMERACTRL_DIR):
    os.chdir(WORK_DIR)
    run("git clone https://github.com/hehao13/CameraCtrl.git")
os.chdir(CAMERACTRL_DIR)

# Install dependencies
run(
    f"{pip} install -q einops omegaconf safetensors decord av 'imageio[ffmpeg]' peft")
run(f"{pip} install -q diffusers==0.21.4 transformers accelerate")

# Download models
run(f"""{python} -c "
from huggingface_hub import snapshot_download, hf_hub_download
import os; os.makedirs('models/Motion_Module', exist_ok=True); os.makedirs('models/CameraCtrl', exist_ok=True)

snapshot_download('runwayml/stable-diffusion-v1-5', local_dir='./models/StableDiffusion',
                  ignore_patterns=['*.ckpt', '*.bin'])
hf_hub_download('guoyww/animatediff', filename='v3_sd15_mm.ckpt', local_dir='./models/Motion_Module')
hf_hub_download('guoyww/animatediff', filename='v3_sd15_adapter.ckpt', local_dir='./models/Motion_Module')
hf_hub_download('hehao13/CameraCtrl', filename='CameraCtrl.ckpt', local_dir='./models/CameraCtrl')
" """)

run("du -sh models/*/")
print()
print("H-drive usage:")
run(f"df -h {H_DRIVE} | tail -1")
