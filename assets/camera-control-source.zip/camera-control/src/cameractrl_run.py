import os
import sys
import glob
import subprocess
import time

H_DRIVE = "/home/hoangp/h-drive"
WORK_DIR = f"{H_DRIVE}/CW"
VENV_DIR = f"{H_DRIVE}/envs/scc456"
LOCAL_WORK = "/tmp/scc456_cameractrl"
CAMERACTRL_DIR = f"{LOCAL_WORK}/CameraCtrl"
OUTPUT_SAVE_DIR = f"{WORK_DIR}/cameractrl_outputs"

pip = f"{VENV_DIR}/bin/pip"
python = f"{VENV_DIR}/bin/python3"
torchrun = f"{VENV_DIR}/bin/torchrun"


def run(cmd, **kwargs):
    subprocess.run(cmd, shell=True, check=True, **kwargs)


if not os.environ.get("VIRTUAL_ENV"):
    os.environ["VIRTUAL_ENV"] = VENV_DIR
    os.environ["PATH"] = f"{VENV_DIR}/bin:" + os.environ["PATH"]

os.environ["HF_HOME"] = f"{LOCAL_WORK}/.cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = f"{os.environ['HF_HOME']}/hub"
os.makedirs(os.environ["HF_HOME"], exist_ok=True)

run(f"""{python} -c "
import torch
assert torch.cuda.is_available(), 'No CUDA GPU detected'
print(f'GPU: {{torch.cuda.get_device_name(0)}}')
print(f'VRAM: {{torch.cuda.get_device_properties(0).total_memory/1e9:.1f}} GB')
" """)

os.makedirs(LOCAL_WORK, exist_ok=True)
if not os.path.isdir(CAMERACTRL_DIR):
    os.chdir(LOCAL_WORK)
    run("git clone https://github.com/hehao13/CameraCtrl.git")
os.chdir(CAMERACTRL_DIR)

run(f"{pip} install -q diffusers==0.21.4 huggingface_hub==0.17.3 transformers==4.34.0")
run(
    f"{pip} install -q einops omegaconf safetensors decord av 'imageio[ffmpeg]'")

run(f"""{python} -c "
from huggingface_hub import snapshot_download, hf_hub_download
import os; os.makedirs('models/Motion_Module', exist_ok=True); os.makedirs('models/CameraCtrl', exist_ok=True)

snapshot_download('runwayml/stable-diffusion-v1-5', local_dir='./models/StableDiffusion',
                  ignore_patterns=['*.ckpt', '*.bin'])
hf_hub_download('guoyww/animatediff', filename='v3_sd15_mm.ckpt', local_dir='./models/Motion_Module')
hf_hub_download('guoyww/animatediff', filename='v3_sd15_adapter.ckpt', local_dir='./models/Motion_Module')
hf_hub_download('hehao13/CameraCtrl', filename='CameraCtrl.ckpt', local_dir='./models/CameraCtrl')
print('All weights downloaded.')
" """)
run("du -sh models/*/")

merged_path = "./models/StableDiffusion/unet_webvidlora_v3/diffusion_pytorch_model.safetensors"
if not os.path.isfile(merged_path):
    print("\nMerging V3 adapter into UNet...")
    run(f"""{python} tools/merge_lora2unet.py \
        --lora_ckpt_path ./models/Motion_Module/v3_sd15_adapter.ckpt \
        --unet_ckpt_path ./models/StableDiffusion \
        --unet_config_path ./models/StableDiffusion/unet/config.json \
        --save_path ./models/StableDiffusion/unet_webvidlora_v3""")
    # Ensure config.json is alongside the weights
    try:
        import shutil
        src = "./models/StableDiffusion/unet/config.json"
        dst = "./models/StableDiffusion/unet_webvidlora_v3/config.json"
        if not os.path.isfile(dst):
            shutil.copy2(src, dst)
    except Exception:
        pass
    print("Merge complete.")
else:
    print("UNet already merged — skipping.")

run(f"{pip} install -q diffusers==0.25.1 huggingface_hub==0.23.5 transformers==4.37.0 peft==0.12.0")

patch_script = os.path.join(CAMERACTRL_DIR, "patch_cameractrl_attention.py")
if not os.path.isfile(patch_script):
    patch_script = os.path.join(WORK_DIR, "patch_cameractrl_attention.py")
run(f"{python} {patch_script}")

# Inference
os.makedirs(OUTPUT_SAVE_DIR, exist_ok=True)


def run_one(pose_file, out_name):
    env = os.environ.copy()
    env["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
    env["CUDA_VISIBLE_DEVICES"] = "0"

    cmd = [
        torchrun, "--standalone", "--nproc_per_node=1",
        "inference.py",
        "--out_root", f"./output/{out_name}",
        "--ori_model_path", "./models/StableDiffusion",
        "--unet_subfolder", "unet_webvidlora_v3",
        "--motion_module_ckpt", "./models/Motion_Module/v3_sd15_mm.ckpt",
        "--pose_adaptor_ckpt", "./models/CameraCtrl/CameraCtrl.ckpt",
        "--model_config", "configs/train_cameractrl/adv3_256_384_cameractrl_relora.yaml",
        "--visualization_captions", "assets/cameractrl_prompts.json",
        "--use_specific_seeds",
        "--trajectory_file", pose_file,
        "--n_procs", "1",
        "--num_inference_steps", "25",
        "--guidance_scale", "7.5",
    ]
    subprocess.run(cmd, env=env, check=True)

    out_dir = f"./output/{out_name}"
    save_dir = f"{OUTPUT_SAVE_DIR}/{out_name}"
    os.makedirs(save_dir, exist_ok=True)
    for ext in ("*.mp4", "*.gif"):
        for f in glob.glob(f"{out_dir}/{ext}"):
            import shutil
            shutil.copy2(f, save_dir)


# Test
pose_files = sorted(glob.glob("assets/pose_files/*.txt"))
first_pose = pose_files[0]
test_name = f"test_{os.path.splitext(os.path.basename(first_pose))[0]}"
run_one(first_pose, test_name)
print("Test complete.")
run("nvidia-smi --query-gpu=memory.used,memory.total --format=csv,noheader 2>/dev/null || true")

if len(sys.argv) > 1 and sys.argv[1] == "--test":
    sys.exit(0)

# Full run
run_start = time.time()
total = len(pose_files)
done = 0
failed = 0

for pose_file in pose_files:
    done += 1
    basename = os.path.splitext(os.path.basename(pose_file))[0]
    print(f"[{done}/{total}] {basename}")
    try:
        run_one(pose_file, basename)
        print("  Done.")
    except subprocess.CalledProcessError:
        failed += 1
        print("  FAILED — continuing")
    run(f"{python} -c 'import torch; torch.cuda.empty_cache()' 2>/dev/null || true")

elapsed = int((time.time() - run_start) / 60)
print(f"Videos saved to: {OUTPUT_SAVE_DIR}")
