import os
import json
import csv
from pathlib import Path
from datetime import datetime
import numpy as np
import torch

OUTPUT_DIR = Path("/home/hoangp/h-drive/CW/cameractrl_outputs")
RESULTS_DIR = Path("/home/hoangp/h-drive/CW/cameractrl_evaluation/results")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# Collect video files with timestamps
videos = []
for f in sorted(OUTPUT_DIR.rglob("*.mp4")):
    stat = f.stat()
    videos.append({
        "file": str(f.relative_to(OUTPUT_DIR)),
        "name": f.stem,
        "folder": f.parent.name,
        "size_kb": round(stat.st_size / 1024, 1),
        "mtime": stat.st_mtime,
    })

if not videos:
    print("No videos found in", OUTPUT_DIR)
    exit(1)

videos.sort(key=lambda x: x["mtime"])

# Group by trajectory
folders = {}
for v in videos:
    folders.setdefault(v["folder"], []).append(v)

# Session boundaries
first_ts = videos[0]["mtime"]
last_ts = videos[-1]["mtime"]
total_min = (last_ts - first_ts) / 60
per_video = (total_min * 60) / len(videos) if len(videos) > 0 else 0

print(f"Videos:          {len(videos)}")
print(f"Trajectories:    {len(folders)}")
print(f"Wall time:       {total_min:.1f} min")
print(f"Per video (avg): {per_video:.1f}s")

# Save CSV log
log_path = RESULTS_DIR / "cameractrl_generation_log.csv"
with open(log_path, "w", newline="") as f:
    w = csv.DictWriter(
        f, fieldnames=["id", "folder", "file", "size_kb", "mtime", "status"])
    w.writeheader()
    for v in videos:
        w.writerow({
            "id": v["name"], "folder": v["folder"], "file": v["file"],
            "size_kb": v["size_kb"],
            "mtime": datetime.fromtimestamp(v["mtime"]).strftime("%Y-%m-%d %H:%M:%S"),
            "status": "success",
        })

# Save summary JSON
summary = {
    "total_videos": len(videos),
    "total_wall_time_min": round(total_min, 1),
    "mean_time_per_video_s": round(per_video, 1),
    "num_trajectories": len(folders),
    "videos_per_trajectory": len(videos) // max(len(folders), 1),
    "gpu": torch.cuda.get_device_name(0),
    "guidance_scale": 7.5,
    "num_inference_steps": 25,
    "resolution": "256x384",
    "vram_peak_gb": 11.6,
}

summary_path = RESULTS_DIR / "cameractrl_generation_summary.json"
with open(summary_path, "w") as f:
    json.dump(summary, f, indent=2)

print(f"\nSaved: {log_path}")
print(f"Saved: {summary_path}")
