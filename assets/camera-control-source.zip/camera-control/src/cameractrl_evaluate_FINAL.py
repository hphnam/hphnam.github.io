import os
import sys
import json
import time
import gc
import csv
import subprocess
from pathlib import Path
from datetime import datetime
import numpy as np
import cv2
import torch
from PIL import Image

H_DRIVE = Path("/home/hoangp/h-drive")
WORK_DIR = H_DRIVE / "CW"

os.environ["HF_HOME"] = "/tmp/scc456_cameractrl/.cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = "/tmp/scc456_cameractrl/.cache/huggingface/hub"

PROJECT_DIR = WORK_DIR / "cameractrl_evaluation"
BASELINE_V3_DIR = PROJECT_DIR / "videos" / "baseline_v3"
RESULTS_DIR = PROJECT_DIR / "results"
FIGURES_DIR = PROJECT_DIR / "figures"

for d in [BASELINE_V3_DIR, RESULTS_DIR, FIGURES_DIR]:
    d.mkdir(parents=True, exist_ok=True)

CAMERACTRL_SEARCH_DIRS = [
    WORK_DIR / "cameractrl_outputs",
    Path("/tmp/scc456_cameractrl/CameraCtrl/output"),
]

PROMPTS_FILE_LOCATIONS = [
    Path("/tmp/scc456_cameractrl/CameraCtrl/assets/cameractrl_prompts.json"),
    WORK_DIR / "CameraCtrl" / "assets" / "cameractrl_prompts.json",
]


def upload_file(local_path, remote_subdir=""):
    if not (os.path.isfile(RCLONE_BIN) and os.path.isfile(RCLONE_CONF)):
        return
    remote = f"{REMOTE_BASE}/{remote_subdir}" if remote_subdir else REMOTE_BASE
    try:
        subprocess.Popen(
            [RCLONE_BIN, "--config", RCLONE_CONF, "copy",
             str(local_path), remote, "--no-traverse"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def find_prompts_file():
    for p in PROMPTS_FILE_LOCATIONS:
        if p.exists():
            return p
    return None


def generate_baseline_v3():
    print("=" * 60)
    print("GENERATING BASELINE: AnimateDiff V3 (text-only)")
    print("=" * 60)

    if not torch.cuda.is_available():
        print("ERROR: No GPU. Use --skip-baseline or --eval-only.")
        return []

    try:
        from diffusers import AnimateDiffPipeline, MotionAdapter, DDIMScheduler
        from diffusers.utils import export_to_gif
    except ImportError as e:
        print(f"ERROR: {e}")
        print("AnimateDiffPipeline not available in current diffusers version.")
        print("Upgrade diffusers or use --skip-baseline.")
        return []

    import imageio

    prompts_file = find_prompts_file()
    if not prompts_file:
        print(f"ERROR: Prompts file not found at any searched location.")
        return []

    with open(prompts_file) as f:
        prompts_data = json.load(f)

    if isinstance(prompts_data, dict) and "prompts" in prompts_data:
        prompts = prompts_data["prompts"]
    elif isinstance(prompts_data, list):
        prompts = prompts_data
    elif isinstance(prompts_data, dict):
        vals = list(prompts_data.values())
        prompts = [v.get("prompt", v.get("text", str(v)))
                   if isinstance(v, dict) else v for v in vals]
    else:
        prompts = [str(prompts_data)]

    print(f"Loaded {len(prompts)} prompts from {prompts_file}")

    try:
        adapter = MotionAdapter.from_pretrained(
            "guoyww/animatediff-motion-adapter-v1-5-2", torch_dtype=torch.float16)
        pipe = AnimateDiffPipeline.from_pretrained(
            "runwayml/stable-diffusion-v1-5", motion_adapter=adapter,
            torch_dtype=torch.float16).to("cuda")
        pipe.scheduler = DDIMScheduler(
            beta_schedule="linear", clip_sample=False, steps_offset=1)
        pipe.enable_vae_slicing()
    except Exception as e:
        print(f"ERROR loading pipeline: {e}")
        return []

    log = []
    for i, prompt in enumerate(prompts):
        prompt_text = prompt.get("prompt", prompt.get("text", str(
            prompt))) if isinstance(prompt, dict) else str(prompt)
        print(f"\n[{i+1}/{len(prompts)}] {prompt_text[:60]}...")
        start = time.time()
        try:
            output = pipe(
                prompt=prompt_text,
                negative_prompt="blurry, low quality, watermark, text, deformed",
                num_frames=16, num_inference_steps=25, guidance_scale=7.5,
                width=384, height=256, generator=torch.manual_seed(42))

            frames = output.frames[0]
            gif_path = BASELINE_V3_DIR / f"baseline_{i:03d}.gif"
            mp4_path = BASELINE_V3_DIR / f"baseline_{i:03d}.mp4"

            export_to_gif(frames, str(gif_path))
            try:
                imageio.mimsave(str(mp4_path), [np.array(f) for f in frames],
                                fps=8, codec='libx264', quality=8)
            except Exception:
                mp4_path = gif_path

            elapsed = time.time() - start
            log.append({"id": f"baseline_{i:03d}", "prompt": prompt_text[:80],
                        "status": "success", "time_s": round(elapsed, 1),
                        "vram_gb": round(torch.cuda.memory_allocated()/1e9, 2), "error": ""})
            print(f"  OK ({elapsed:.1f}s)")
            upload_file(mp4_path, "baseline_v3")
        except Exception as e:
            log.append({"id": f"baseline_{i:03d}", "prompt": prompt_text[:80],
                        "status": "failed", "time_s": 0, "vram_gb": 0, "error": str(e)})
            print(f"  FAILED: {e}")
        torch.cuda.empty_cache()
        gc.collect()

    log_path = RESULTS_DIR / "baseline_v3_generation_log.csv"
    with open(log_path, "w", newline="") as f:
        csv.DictWriter(f, fieldnames=[
                       "id", "prompt", "status", "time_s", "vram_gb", "error"]).writeheader()
        csv.DictWriter(f, fieldnames=[
                       "id", "prompt", "status", "time_s", "vram_gb", "error"]).writerows(log)
    upload_file(log_path, "results")

    del pipe, adapter
    torch.cuda.empty_cache()
    gc.collect()
    return log

# optical flow


def load_video_frames(path):
    frames = []
    cap = cv2.VideoCapture(str(path))
    if cap.isOpened():
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        cap.release()
        if frames:
            return frames
    try:
        gif = Image.open(str(path))
        while True:
            frames.append(np.array(gif.convert("RGB")))
            gif.seek(gif.tell() + 1)
    except (EOFError, OSError):
        pass
    return frames


def compute_optical_flow(frames):
    if len(frames) < 2:
        return None
    h, w = frames[0].shape[:2]
    cx, cy = w/2.0, h/2.0
    angles, mags, fxs, fys, radials = [], [], [], [], []

    for i in range(len(frames)-1):
        prev = cv2.cvtColor(frames[i], cv2.COLOR_RGB2GRAY)
        curr = cv2.cvtColor(frames[i+1], cv2.COLOR_RGB2GRAY)
        flow = cv2.calcOpticalFlowFarneback(
            prev, curr, None, 0.5, 3, 15, 3, 5, 1.2, 0)
        fx, fy = flow[..., 0], flow[..., 1]
        mag, ang = cv2.cartToPolar(fx, fy)
        w_ = mag + 1e-8
        a = np.degrees(np.average(ang, weights=w_))
        angles.append(0.0 if np.isnan(a) else a)
        m = float(np.mean(mag))
        mags.append(0.0 if np.isnan(m) else m)
        fxs.append(float(np.mean(fx)))
        fys.append(float(np.mean(fy)))
        yy, xx = np.mgrid[0:h, 0:w]
        rx, ry = (xx-cx)/(w/2.0), (yy-cy)/(h/2.0)
        rn = np.sqrt(rx**2 + ry**2) + 1e-8
        radials.append(float(np.mean((fx*rx + fy*ry)/rn)))

    return {
        "mean_direction_deg": round(float(np.nanmean(angles)), 2),
        "direction_std_deg": round(float(np.nanstd(angles)), 2),
        "mean_magnitude": round(float(np.nanmean(mags)), 4),
        "magnitude_std": round(float(np.nanstd(mags)), 4),
        "flow_x_mean": round(float(np.nanmean(fxs)), 4),
        "flow_y_mean": round(float(np.nanmean(fys)), 4),
        "radial_divergence": round(float(np.nanmean(radials)), 4),
    }


def find_all_videos(dirs, label):
    """Find video files across directories, deduplicated by stem."""
    videos = []
    seen = set()
    for d in dirs:
        d = Path(d)
        if not d.exists():
            continue
        for f in sorted(d.rglob("*.mp4")) + sorted(d.rglob("*.gif")):
            if f.stem not in seen and f.is_file():
                seen.add(f.stem)
                videos.append(f)
    print(f"  {label}: {len(videos)} videos found across {len(dirs)} dirs")
    return videos


def evaluate_all_videos():
    print("\n" + "=" * 60)
    print("EVALUATING OPTICAL FLOW: Baseline V3 vs CameraCtrl")
    print("=" * 60)

    results = []

    # Baseline V3
    baseline_videos = find_all_videos([BASELINE_V3_DIR], "Baseline V3")
    for vp in baseline_videos:
        frames = load_video_frames(vp)
        if len(frames) < 2:
            continue
        m = compute_optical_flow(frames)
        if m:
            m["id"] = vp.stem
            m["condition"] = "baseline_v3"
            results.append(m)
        print(
            f"    {vp.name}: mag={m['mean_magnitude']:.4f}" if m else f"    {vp.name}: skipped")

    # CameraCtrl
    cc_videos = find_all_videos(CAMERACTRL_SEARCH_DIRS, "CameraCtrl")
    for vp in cc_videos:
        frames = load_video_frames(vp)
        if len(frames) < 2:
            continue
        m = compute_optical_flow(frames)
        if m:
            m["id"] = vp.stem
            m["condition"] = "cameractrl"
            results.append(m)
        print(
            f"    {vp.name}: mag={m['mean_magnitude']:.4f}" if m else f"    {vp.name}: skipped")

    if results:
        csv_path = RESULTS_DIR / "cameractrl_flow_results.csv"
        fns = ["id", "condition", "mean_direction_deg", "direction_std_deg",
               "mean_magnitude", "magnitude_std", "flow_x_mean", "flow_y_mean", "radial_divergence"]
        with open(csv_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fns)
            w.writeheader()
            w.writerows(results)
        print(f"\nResults saved: {csv_path} ({len(results)} videos)")
        upload_file(csv_path, "results")
    else:
        print("\nWARNING: No videos found!")
        for d in [BASELINE_V3_DIR] + CAMERACTRL_SEARCH_DIRS:
            print(f"  {'EXISTS' if d.exists() else 'MISSING'}: {d}")
    return results


def generate_figures(results):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    matplotlib.rcParams['font.family'] = 'sans-serif'
    matplotlib.rcParams['font.size'] = 12

    if not results:
        print("No results.")
        return
    bl = [r for r in results if r["condition"] == "baseline_v3"]
    cc = [r for r in results if r["condition"] == "cameractrl"]

    if not bl or not cc:
        print(
            f"Need both conditions. Baseline: {len(bl)}, CameraCtrl: {len(cc)}")
        return

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))

    for ax, key, ylabel, title in [
        (axes[0], "mean_magnitude",
         "Mean Optical Flow Magnitude", "Motion Strength"),
        (axes[1], "direction_std_deg",
         "Direction Std Dev (deg) — lower=better", "Motion Consistency"),
        (axes[2], "radial_divergence", "Radial Divergence", "Depth Motion"),
    ]:
        bl_v = [r[key] for r in bl]
        cc_v = [r[key] for r in cc]
        ax.bar(["Baseline V3\n(text-only)", "CameraCtrl\n(3D pose)"],
               [np.mean(bl_v), np.mean(cc_v)], yerr=[np.std(bl_v), np.std(cc_v)],
               color=["#95A5A6", "#E74C3C"], capsize=6, width=0.5, edgecolor="white")
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.3)

    plt.suptitle("AnimateDiff V3 Baseline vs CameraCtrl",
                 fontsize=14, fontweight="bold")
    plt.tight_layout()
    for ext in ["png", "pdf"]:
        p = FIGURES_DIR / f"cameractrl_comparison.{ext}"
        fig.savefig(p, dpi=150, bbox_inches="tight")
        upload_file(p, "figures")
    plt.close(fig)
    print(f"Figures saved to: {FIGURES_DIR}")

    # Summary table
    print("\n" + "=" * 62)
    fmt = "{:<25} {:>18} {:>18}"
    print(fmt.format("Metric", "Baseline V3", "CameraCtrl"))
    print("-" * 62)
    for label, key in [("Magnitude", "mean_magnitude"), ("Dir Std (deg)", "direction_std_deg"), ("Radial Div", "radial_divergence")]:
        bl_v = [r[key] for r in bl]
        cc_v = [r[key] for r in cc]
        print(fmt.format(label, f"{np.mean(bl_v):.4f}+/-{np.std(bl_v):.4f}",
                         f"{np.mean(cc_v):.4f}+/-{np.std(cc_v):.4f}"))
    print(fmt.format("N videos", str(len(bl)), str(len(cc))))

    # CSV table
    table_path = RESULTS_DIR / "cameractrl_summary.csv"
    with open(table_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Metric", "Baseline_mean", "Baseline_std",
                   "CameraCtrl_mean", "CameraCtrl_std"])
        for label, key in [("Magnitude", "mean_magnitude"), ("Direction_Std", "direction_std_deg"), ("Radial_Div", "radial_divergence")]:
            bl_v = [r[key] for r in bl]
            cc_v = [r[key] for r in cc]
            w.writerow([label, f"{np.mean(bl_v):.4f}", f"{np.std(bl_v):.4f}",
                        f"{np.mean(cc_v):.4f}", f"{np.std(cc_v):.4f}"])
    upload_file(table_path, "results")


# CLIP
def evaluate_clip_consistency():
    """CLIP frame-to-frame cosine similarity, matching MotionLoRA Section 5 methodology."""
    print("\n" + "=" * 60)
    print("EVALUATING CLIP FRAME CONSISTENCY")
    print("=" * 60)

    try:
        import open_clip
    except ImportError:
        print("WARNING: open_clip not installed. Skipping CLIP evaluation.")
        print("  Install with: pip install open-clip-torch")
        return []

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"  CLIP device: {device}")

    try:
        clip_model, _, clip_preprocess = open_clip.create_model_and_transforms(
            "ViT-B-32", pretrained="openai")
        clip_model = clip_model.to(device).eval()
    except Exception as e:
        print(f"WARNING: Failed to load CLIP model: {e}")
        return []

    def clip_frame_similarity(frames):
        if len(frames) < 2:
            return None
        with torch.no_grad():
            embeddings = []
            for frame in frames:
                pil_img = Image.fromarray(frame) if isinstance(
                    frame, np.ndarray) else frame
                img_tensor = clip_preprocess(pil_img).unsqueeze(0).to(device)
                emb = clip_model.encode_image(img_tensor)
                emb = emb / emb.norm(dim=-1, keepdim=True)
                embeddings.append(emb.cpu())
        sims = []
        for i in range(len(embeddings) - 1):
            sims.append(torch.cosine_similarity(
                embeddings[i], embeddings[i+1]).item())
        return {
            "clip_mean_similarity": round(float(np.mean(sims)), 4),
            "clip_std_similarity": round(float(np.std(sims)), 4),
            "clip_min_similarity": round(float(np.min(sims)), 4),
        }

    clip_results = []

    # Baseline V3
    baseline_videos = find_all_videos([BASELINE_V3_DIR], "Baseline V3 (CLIP)")
    for vp in baseline_videos:
        frames = load_video_frames(vp)
        if len(frames) < 2:
            continue
        m = clip_frame_similarity(frames)
        if m:
            m["id"] = vp.stem
            m["condition"] = "baseline_v3"
            clip_results.append(m)

    # CameraCtrl
    cc_videos = find_all_videos(CAMERACTRL_SEARCH_DIRS, "CameraCtrl (CLIP)")
    for vp in cc_videos:
        frames = load_video_frames(vp)
        if len(frames) < 2:
            continue
        m = clip_frame_similarity(frames)
        if m:
            m["id"] = vp.stem
            m["condition"] = "cameractrl"
            clip_results.append(m)

    if clip_results:
        csv_path = RESULTS_DIR / "cameractrl_clip_consistency.csv"
        fns = ["id", "condition", "clip_mean_similarity",
               "clip_std_similarity", "clip_min_similarity"]
        with open(csv_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fns)
            w.writeheader()
            w.writerows(clip_results)
        upload_file(csv_path, "results")

        bl_clip = [r["clip_mean_similarity"]
                   for r in clip_results if r["condition"] == "baseline_v3"]
        cc_clip = [r["clip_mean_similarity"]
                   for r in clip_results if r["condition"] == "cameractrl"]
        print(
            f"\n  Baseline V3 CLIP sim: {np.mean(bl_clip):.4f} +/- {np.std(bl_clip):.4f} (n={len(bl_clip)})")
        print(
            f"  CameraCtrl CLIP sim:  {np.mean(cc_clip):.4f} +/- {np.std(cc_clip):.4f} (n={len(cc_clip)})")
        print(f"  Results saved: {csv_path}")
    else:
        print("  WARNING: No CLIP results produced.")

    del clip_model
    torch.cuda.empty_cache()
    gc.collect()

    return clip_results


MOTIONLORA_RESULTS_SEARCH = [
    WORK_DIR / "motionlora_project" / "results" / "optical_flow_results.csv",
    H_DRIVE / "CW" / "motionlora_project" / "results" / "optical_flow_results.csv",
    Path("./motionlora_project/results/optical_flow_results.csv"),
]


def find_motionlora_results():
    for p in MOTIONLORA_RESULTS_SEARCH:
        if p.exists():
            print(f"  Found MotionLoRA results: {p}")
            return p
    return None


def unified_three_way_comparison(cameractrl_results, clip_results=None):
    print("\n" + "=" * 70)
    print("UNIFIED THREE-WAY COMPARISON")
    print("=" * 70)

    ml_path = find_motionlora_results()
    if not ml_path:
        print("\nMotionLoRA CSV not found.")
        print("Searched:", [str(p) for p in MOTIONLORA_RESULTS_SEARCH])
        return

    import csv as csv_mod
    with open(ml_path, newline="") as f:
        ml_all = list(csv_mod.DictReader(f))

    for r in ml_all:
        for k in ["mean_magnitude", "direction_std_deg", "radial_divergence", "mean_direction_deg"]:
            if k in r:
                try:
                    r[k] = float(r[k])
                except (ValueError, TypeError):
                    r[k] = 0.0

    ml_baseline = [r for r in ml_all if r.get("condition") == "baseline"]
    ml_lora = [r for r in ml_all if r.get("condition") == "motionlora"]

    cc_baseline = [
        r for r in cameractrl_results if r["condition"] == "baseline_v3"]
    cc_ctrl = [r for r in cameractrl_results if r["condition"] == "cameractrl"]

    print(f"\n  MotionLoRA baseline videos: {len(ml_baseline)}")
    print(f"  MotionLoRA adapter videos:  {len(ml_lora)}")
    print(f"  CameraCtrl baseline videos: {len(cc_baseline)}")
    print(f"  CameraCtrl pose videos:     {len(cc_ctrl)}")

    if not ml_baseline or not ml_lora:
        print("MotionLoRA results incomplete")
        return
    if not cc_baseline or not cc_ctrl:
        print("CameraCtrl results incomplete")
        return

    def safe_mean(vals):
        v = [x for x in vals if not np.isnan(x)]
        return np.mean(v) if v else 0.0

    def safe_std(vals):
        v = [x for x in vals if not np.isnan(x)]
        return np.std(v) if v else 0.0

    unified_path = RESULTS_DIR / "unified_three_way_comparison.csv"
    with open(unified_path, "w", newline="") as f:
        w = csv_mod.DictWriter(f, fieldnames=[
            "metric", "ml_baseline", "ml_experimental", "ml_lift_pct",
            "cc_baseline", "cc_experimental", "cc_lift_pct"])
        w.writeheader()
        w.writerows(lift_rows)
    upload_file(unified_path, "results")
    print(f"\nUnified comparison saved: {unified_path}")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(1, 2, figsize=(12, 5))

        # Lift comparison
        ax = axes[0]
        metrics = ["Magnitude", "Dir Std"]
        ml_lifts = [float(r["ml_lift_pct"].replace(
            "%", "").replace("+", "")) for r in lift_rows]
        cc_lifts = [float(r["cc_lift_pct"].replace(
            "%", "").replace("+", "")) for r in lift_rows]
        x = np.arange(len(metrics))
        w_ = 0.35
        ax.bar(x - w_/2, ml_lifts, w_, label="MotionLoRA lift",
               color="#2E86C1", edgecolor="white")
        ax.bar(x + w_/2, cc_lifts, w_, label="CameraCtrl lift",
               color="#E74C3C", edgecolor="white")
        ax.set_ylabel("% Change from Baseline")
        ax.set_title("Relative Improvement Over Own Baseline")
        ax.set_xticks(x)
        ax.set_xticklabels(metrics)
        ax.axhline(y=0, color="gray", linewidth=0.5)
        ax.legend()
        ax.grid(axis="y", alpha=0.3)

        # Direction consistency
        ax = axes[1]
        vals = [a_dir, b_dir, c_dir]
        colors = ["#95A5A6", "#2E86C1", "#E74C3C"]
        labels = ["Text-only\n(A)", "MotionLoRA\n(B)", "CameraCtrl\n(C)"]
        ax.bar(labels, vals, color=colors, width=0.5, edgecolor="white")
        ax.set_ylabel("Direction Std Dev (\u00B0) \u2014 lower = better")
        ax.set_title("Direction Consistency (resolution-independent)")
        ax.grid(axis="y", alpha=0.3)

        plt.suptitle("Three-Way Comparison: Text vs MotionLoRA vs CameraCtrl",
                     fontsize=14, fontweight="bold")
        plt.tight_layout()
        for ext in ["png", "pdf"]:
            p = FIGURES_DIR / f"unified_three_way.{ext}"
            fig.savefig(p, dpi=150, bbox_inches="tight")
            upload_file(p, "figures")
        plt.close(fig)
        print(
            f"Three-way figure saved: {FIGURES_DIR / 'unified_three_way.png'}")
    except Exception as e:
        print(f"Figure generation error: {e}")

    print("\n" + "=" * 70)
    print("DONE. Copy the tables above into Executive Summary Section 5.5.")
    print("=" * 70)


if __name__ == "__main__":
    print("=" * 60)
    print("SCC 456 — CameraCtrl Evaluation")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(
        f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'None'}")
    print("=" * 60)

    skip = "--skip-baseline" in sys.argv
    eval_only = "--eval-only" in sys.argv
    unified_only = "--unified-only" in sys.argv

    if unified_only:
        csv_path = RESULTS_DIR / "cameractrl_flow_results.csv"
        clip_path = RESULTS_DIR / "cameractrl_clip_consistency.csv"
        if csv_path.exists():
            import csv as csv_mod
            with open(csv_path, newline="") as f:
                results = []
                for r in csv_mod.DictReader(f):
                    for k in ["mean_magnitude", "direction_std_deg", "radial_divergence", "mean_direction_deg", "magnitude_std", "flow_x_mean", "flow_y_mean"]:
                        if k in r:
                            try:
                                r[k] = float(r[k])
                            except:
                                r[k] = 0.0
                    results.append(r)
            clip_results = []
            if clip_path.exists():
                with open(clip_path, newline="") as f:
                    for r in csv_mod.DictReader(f):
                        for k in ["clip_mean_similarity", "clip_std_similarity", "clip_min_similarity"]:
                            if k in r:
                                try:
                                    r[k] = float(r[k])
                                except:
                                    r[k] = 0.0
                        clip_results.append(r)
            print(
                f"Loaded {len(results)} flow results, {len(clip_results)} CLIP results")
            unified_three_way_comparison(results, clip_results)
        else:
            print(f"ERROR: {csv_path} not found. Run full evaluation first.")
        sys.exit(0)

    if not eval_only and not skip:
        generate_baseline_v3()
    elif skip:
        print("Skipping baseline generation.")

    results = evaluate_all_videos()
    clip_results = evaluate_clip_consistency()
    generate_figures(results)
    unified_three_way_comparison(results, clip_results)

    print(f"\n{RESULTS_DIR}")
