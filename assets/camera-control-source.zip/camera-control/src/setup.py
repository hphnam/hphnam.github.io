import os
import sys
import shutil
import subprocess

H_DRIVE = "/home/hoangp/h-drive"
WORK_DIR = f"{H_DRIVE}/CW"
VENV_DIR = f"{H_DRIVE}/envs/scc456"
HF_CACHE = f"{H_DRIVE}/.cache/huggingface"


def run(cmd, **kwargs):
    subprocess.run(cmd, shell=True, check=True, **kwargs)


print("SCC456 environment setup")

PYTHON_BIN = shutil.which("python3")
if not PYTHON_BIN:
    print("python3 not found")
    sys.exit(1)
result = subprocess.run(["python3", "--version"],
                        capture_output=True, text=True)
print(f"Python: {PYTHON_BIN} ({result.stdout.strip()})")

if os.path.isdir(VENV_DIR):
    shutil.rmtree(VENV_DIR)

os.makedirs(os.path.dirname(VENV_DIR), exist_ok=True)
run(f"python3 -m venv --copies {VENV_DIR}")

pip = f"{VENV_DIR}/bin/pip"
python = f"{VENV_DIR}/bin/python"

run(f"{pip} install --upgrade pip setuptools wheel -q")

# PyTorch with CUDA 12.1
run(f"{pip} install torch torchvision --index-url https://download.pytorch.org/whl/cu121 -q")

# Diffusers ecosystem
run(f"{pip} install diffusers transformers accelerate -q")

# LoRA
run(f"{pip} install peft -q")

run(f"{pip} install torchmetrics open-clip-torch -q")

run(f"{pip} install opencv-python-headless matplotlib pandas pillow imageio -q")
run(f"{pip} install 'imageio[ffmpeg]' -q")

run(f"{pip} install ipykernel -q")
run(f"{python} -m ipykernel install --user --name scc456 --display-name 'SCC456 (GPU)'")

# HuggingFace cache
os.makedirs(HF_CACHE, exist_ok=True)

print()
print("Setup complete.")
print(f"  venv:  {VENV_DIR}")
print(f"  cache: {HF_CACHE}")
