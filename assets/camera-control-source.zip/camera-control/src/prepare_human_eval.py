import random
import shutil
import csv
from pathlib import Path

MOTIONLORA_BASELINE_DIR = Path(
    "/home/hoangp/h-drive/CW/motionlora_project/videos/baseline")
MOTIONLORA_EXPERIMENT_DIR = Path(
    "/home/hoangp/h-drive/CW/motionlora_project/videos/motionlora")
CAMERACTRL_BASELINE_DIR = Path(
    "/home/hoangp/h-drive/CW/cameractrl_evaluation/videos/baseline_v3")
CAMERACTRL_EXPERIMENT_DIR = Path("/home/hoangp/h-drive/CW/cameractrl_outputs")
OUTPUT_DIR = Path("/home/hoangp/h-drive/CW/human_eval_videos")

SEED = 42


def collect_videos():
    videos = []
    motion_map = {
        "pan_left": "Pan Left",
        "pan_right": "Pan Right",
        "zoom_in": "Zoom In",
        "zoom_out": "Zoom Out",
    }

    if MOTIONLORA_BASELINE_DIR.exists():
        bl_files = sorted(MOTIONLORA_BASELINE_DIR.glob("*.mp4"))
        if not bl_files:
            bl_files = sorted(MOTIONLORA_BASELINE_DIR.glob("*.gif"))

        # Group by motion type
        by_motion = {}
        for f in bl_files:
            detected_motion = "Unknown"
            for key, label in motion_map.items():
                if key in f.stem:
                    detected_motion = label
                    break
            by_motion.setdefault(detected_motion, []).append(f)

        selected_bl = []
        for motion_label, files in by_motion.items():
            random.seed(SEED)
            pick = min(3, len(files))
            selected_bl.extend(random.sample(files, pick))

        random.seed(SEED + 1)
        if len(selected_bl) > 10:
            selected_bl = random.sample(selected_bl, 10)

        for f in selected_bl:
            expected = "Unknown"
            for key, label in motion_map.items():
                if key in f.stem:
                    expected = label
                    break
            videos.append({
                "condition": "Text-only baseline",
                "experiment": "MotionLoRA (512x512)",
                "expected_motion": expected,
                "original_id": f.stem,
                "source_path": f,
            })
        print(f"MotionLoRA baseline: {len(selected_bl)} videos selected")
    else:
        print(f"{MOTIONLORA_BASELINE_DIR} not found")

    if MOTIONLORA_EXPERIMENT_DIR.exists():
        ml_files = sorted(MOTIONLORA_EXPERIMENT_DIR.glob("*.mp4"))
        if not ml_files:
            ml_files = sorted(MOTIONLORA_EXPERIMENT_DIR.glob("*.gif"))

        by_motion = {}
        for f in ml_files:
            detected_motion = "Unknown"
            for key, label in motion_map.items():
                if key in f.stem:
                    detected_motion = label
                    break
            by_motion.setdefault(detected_motion, []).append(f)

        selected_ml = []
        for motion_label, files in by_motion.items():
            random.seed(SEED + 2)
            pick = min(3, len(files))
            selected_ml.extend(random.sample(files, pick))

        random.seed(SEED + 3)
        if len(selected_ml) > 10:
            selected_ml = random.sample(selected_ml, 10)

        for f in selected_ml:
            expected = "Unknown"
            for key, label in motion_map.items():
                if key in f.stem:
                    expected = label
                    break
            videos.append({
                "condition": "MotionLoRA adapter",
                "experiment": "MotionLoRA (512x512)",
                "expected_motion": expected,
                "original_id": f.stem,
                "source_path": f,
            })
        print(f"  MotionLoRA experiment: {len(selected_ml)} videos selected")
    else:
        print(f"{MOTIONLORA_EXPERIMENT_DIR} not found")

    if CAMERACTRL_BASELINE_DIR.exists():
        cc_bl_files = sorted(CAMERACTRL_BASELINE_DIR.glob("*.mp4"))
        if not cc_bl_files:
            cc_bl_files = sorted(CAMERACTRL_BASELINE_DIR.glob("*.gif"))

        random.seed(SEED + 4)
        pick = min(5, len(cc_bl_files))
        selected_cc_bl = random.sample(cc_bl_files, pick)

        for f in selected_cc_bl:
            videos.append({
                "condition": "Text-only baseline",
                "experiment": "CameraCtrl (256x384)",
                "expected_motion": "Complex / Multi-axis",
                "original_id": f.stem,
                "source_path": f,
            })
        print(f"  CameraCtrl baseline: {len(selected_cc_bl)} videos selected")
    else:
        print(f"{CAMERACTRL_BASELINE_DIR} not found")

    if CAMERACTRL_EXPERIMENT_DIR.exists():
        cc_files = sorted(CAMERACTRL_EXPERIMENT_DIR.rglob("*.mp4"))
        if not cc_files:
            cc_files = sorted(CAMERACTRL_EXPERIMENT_DIR.rglob("*.gif"))

        random.seed(SEED + 5)
        pick = min(5, len(cc_files))
        selected_cc = random.sample(cc_files, pick)

        for f in selected_cc:
            videos.append({
                "condition": "CameraCtrl (3D pose)",
                "experiment": "CameraCtrl (256x384)",
                "expected_motion": "Complex / Multi-axis",
                "original_id": f.stem,
                "source_path": f,
            })
        print(f"  CameraCtrl experiment: {len(selected_cc)} videos selected")
    else:
        print(f"  WARNING: {CAMERACTRL_EXPERIMENT_DIR} not found")

    return videos


def main():
    print("=" * 60)
    print("SCC 456 — Human Evaluation Video Preparation")
    print("=" * 60)

    # Collect all videos
    videos = collect_videos()
    print(f"\nTotal videos collected: {len(videos)}")

    if len(videos) == 0:
        print("no videos found.")
        return

    random.seed(SEED)
    random.shuffle(videos)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    answer_key = []
    for i, v in enumerate(videos):
        eval_id = f"EVAL_{i+1:03d}"
        ext = v["source_path"].suffix  # .mp4 or .gif
        dst = OUTPUT_DIR / f"{eval_id}{ext}"

        shutil.copy2(v["source_path"], dst)

        answer_key.append({
            "eval_id": eval_id,
            "filename": f"{eval_id}{ext}",
            "true_condition": v["condition"],
            "experiment": v["experiment"],
            "expected_motion": v["expected_motion"],
            "original_id": v["original_id"],
            "original_path": str(v["source_path"]),
        })

    key_path = OUTPUT_DIR.parent / "human_eval_answer_key.csv"
    with open(key_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "eval_id", "filename", "true_condition", "experiment",
            "expected_motion", "original_id", "original_path"
        ])
        writer.writeheader()
        writer.writerows(answer_key)

    print("DISTRIBUTION")
    from collections import Counter
    cond_counts = Counter(r["true_condition"] for r in answer_key)
    exp_counts = Counter(r["experiment"] for r in answer_key)
    motion_counts = Counter(r["expected_motion"] for r in answer_key)

    print("  By condition:")
    for k, v in sorted(cond_counts.items()):
        print(f"    {k}: {v}")
    print("  By experiment:")
    for k, v in sorted(exp_counts.items()):
        print(f"    {k}: {v}")
    print("  By expected motion:")
    for k, v in sorted(motion_counts.items()):
        print(f"    {k}: {v}")


if __name__ == "__main__":
    main()
