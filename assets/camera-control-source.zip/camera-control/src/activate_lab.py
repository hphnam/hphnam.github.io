import os
import subprocess

H_DRIVE = "/home/hoangp/h-drive"
VENV_DIR = f"{H_DRIVE}/envs/scc456"
WORK_DIR = f"{H_DRIVE}/CW"

os.environ["VIRTUAL_ENV"] = VENV_DIR
os.environ["PATH"] = f"{VENV_DIR}/bin:" + os.environ["PATH"]

os.environ["HF_HOME"] = f"{H_DRIVE}/.cache/huggingface"
os.environ["TRANSFORMERS_CACHE"] = f"{os.environ['HF_HOME']}/hub"

os.chdir(WORK_DIR)

result = subprocess.run(
    ["python", "-c",
        'import torch; print(f"torch {torch.__version__}, CUDA {torch.cuda.is_available()}")'],
    capture_output=True, text=True
)
print(f"SCC456 env active | {result.stdout.strip()}")
