# Camera control in AI generated video

Nam Hoang's research comparing text prompts, MotionLoRA adapters and CameraCtrl on a 12 GB campus GPU. The portfolio case explains the findings through original clips and interactive illustrations.

## What this repository contains

- `src/`: the original experiment notebook, environment scripts, single-GPU CameraCtrl runner, SDPA attention patch, evaluation pipeline and blind-study preparation script.
- `motionlora_project/`: the 40-pair prompt dataset and measured results for AnimateDiff V2, at 512 × 512.
- `cameractrl_evaluation/`: measured results for CameraCtrl and its matched AnimateDiff V3 baseline, at 256 × 384.
- `human_evaluation_summary.csv`: aggregate results calculated from the three supplied evaluation CSVs. Individual evaluator names are omitted.

The notebook's saved outputs have been cleared. Videos, model weights, personal evaluation responses and the old presentation are not bundled here. Representative original videos are available in the portfolio case.

## Experimental design

These are **two controlled experiments**, rather than one matched three-arm trial. V2 text prompting and MotionLoRA share prompts, resolution, seed and generation settings. V3 text prompting and CameraCtrl share their own prompts and resolution. Cross-experiment model versions, scenes, resolution and guidance differ. The summary CSV reports each adapter's percentage change against its own baseline.

MotionLoRA's mean flow magnitude increased from 1.0483 to 5.6941 pixels per frame (+443.2%). CameraCtrl's fell from 18.7422 to 7.5795 (−59.6%). CameraCtrl's radial flow changed from −0.2356 to +2.5212, consistent with forward translation. Radial flow alone cannot establish complete 3D pose accuracy. The study did not complete a COLMAP pose-error benchmark.

The blind study used 30 videos and three evaluators (90 judgements). MotionLoRA's intended direction was identified in 26/30 judgements (86.7%). CameraCtrl had discernible motion in 15/15 judgements (100%), while its expected “Complex / Multi-axis” label was selected in 9/15 (60%). Text-only results pooled across both experiments were 2/45 correct intended labels (4.4%); the V2 subset was 2/30 (6.7%). These definitions explain the differing percentages in the report.

## Running the original research

This is an archived research implementation, not a packaged inference service. Python scripts contain campus-specific `/home/hoangp/h-drive` and `/tmp/scc456_cameractrl` paths. Update these paths for your machine before executing anything. CUDA hardware and separately downloaded model weights are required. No credentials or weights are provided.

1. Review `src/setup.py` and `src/activate_lab.py` for the original environment and cache configuration.
2. Run the MotionLoRA notebook in a CUDA environment. Generation requires PyTorch, Diffusers, Transformers, PEFT and ImageIO. Evaluation also uses OpenCV, NumPy, pandas, matplotlib and OpenCLIP.
3. For CameraCtrl, review `src/cameractrl_setup.py` and `src/cameractrl_run.py`. The runner clones the upstream repository, downloads weights, merges the V3 domain adapter, and runs one process with `torchrun`.
4. Place `src/patch_cameractrl_attention.py` at the upstream CameraCtrl root before the runner's inference stage, then apply the patch. It replaces explicit attention-score materialisation with PyTorch SDPA. Available fused backends depend on hardware, dtype and tensor shape.
5. Review `src/cameractrl_evaluate_FINAL.py` before running. Its optional background uploader refers to lab-only `RCLONE_BIN`, `RCLONE_CONF` and `REMOTE_BASE` values that are not supplied; remove or configure that helper for your environment. The provided CSVs can be inspected without running generation.

The original CameraCtrl dependency sequence uses Diffusers 0.21.4 for merging and 0.25.1 for inference. Consult the runner for the remaining original pins. These dependencies reflect the experiment environment, not a promise of compatibility with current packages.

## Attribution

Research design, experiment orchestration, evaluation and portfolio interpretation: Nam Hoang. The CameraCtrl inference adaptation builds on Hao He and collaborators' implementation. Pretrained AnimateDiff, MotionLoRA and CameraCtrl models are upstream research contributions, not models trained for this project.

- [AnimateDiff](https://github.com/guoyww/AnimateDiff)
- [CameraCtrl](https://github.com/hehao13/CameraCtrl)
- [CameraCtrl paper](https://arxiv.org/abs/2404.02101)
- [PyTorch SDPA documentation](https://docs.pytorch.org/docs/stable/generated/torch.nn.functional.scaled_dot_product_attention.html)

This archive does not assign a new licence to upstream code or model weights. Refer to each upstream project's terms before reuse.
