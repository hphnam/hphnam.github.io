# SCC.451 coursework notebooks

Nine supplied notebooks, with saved outputs. Local machine paths and execution metadata removed from these public copies. Original datasets and extracted feature files are not included, so rerunning requires those inputs and the Python dependencies imported in the notebooks.

The case page distinguishes the submitted report benchmark from the saved classification notebook run. The ALD-mixture implementation is an exploratory BQC-inspired approximation, not full Bayesian inference.
